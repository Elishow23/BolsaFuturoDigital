n = int(input("Informe um numero: "))

if n % 2 == 0:
    print('Numero Par')
else:
    print('Numero Impar')