n = int(input('Digite numero:  '))

for i in range(11):
    r = n * i
    print('    ',n,' X ',i,' = ',r)
    