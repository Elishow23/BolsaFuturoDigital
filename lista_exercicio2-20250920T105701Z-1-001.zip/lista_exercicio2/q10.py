#10-Peça um número N e some todos os números primos de 1 até N.
#Exiba o resultado

n = int(input('Digite um numero: '))

for i in range(n):
    if i 