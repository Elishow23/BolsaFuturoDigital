n = int(input('Digite um numero: '))
soma = 0
for i in range(n):
    soma = soma + (i+1)

print('    ', soma)