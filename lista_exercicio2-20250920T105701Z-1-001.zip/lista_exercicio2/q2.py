n1 = float(input('Informa o primeiro numero: '))
n2 = float(input('Informe o segundo numero: '))

if n1 > n2:
    print('Numero maior é: ', n1)
else:
    print('Numero maior é: ', n2)