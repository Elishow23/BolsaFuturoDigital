n = 0

while n < 10:
    n = n + 1
    print('   ',n)